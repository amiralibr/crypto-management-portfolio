# Workspace and evidence — REPORTS, NOT INDEPENDENT VERIFICATION
## Known owner-side Git workspace
C:\Users\Barkhordari\AppData\Local\Temp\mvp0-f4-dec011-r1-b1680063cf804e0baf675aa83be42cdc\repo
Reported HEAD: e6b33bb4f8f91170782139dec85ede13cda3a24b
Reported clean, detached, no nonignored untracked paths. Ignored ruff/mypy caches preserved.
Documents session folder was reported not a Git repository.

## Known Arena-side workspace
/home/user/crypto-management-portfolio
Reported HEAD: e5ce70619b48922ad7ee09e4aec2d7b4ee19370b
Reported branch: arena/01a0fca1-crypto-management-portfolio
Reported latest decoration: grafted; working tree dirty, README modified and many untracked paths. Attempts stopped before changes/tests/migrations.
Arena UI showed GitHub connected and a large diff. This does not prove canonical content equivalence, cause of the mismatch, or remote branch state.
Windows and Linux absolute paths do NOT need to match. Execution content must match the approved fixed baseline, and existing work must be preserved.

## Reported ancestry from owner's object database
Technical baseline: 9cf204d88fbcc1af0428331f866348a013f6aec0
Official F4 historical working start: c2bf56dea0f14e6cc4ee7052d7fbb9da9d5cadf4
Reported chain: c2bf56d -> 891af34 -> e6b33bb
Owner reports last two commits documentation/package-only. Ancestor relation alone is not proof of zero code differences; an exact tree/path diff remains the supporting evidence.
e5ce706 was reported as root/initial commit in owner repo. Why Arena remains there is UNKNOWN; cache/seed explanations are hypotheses, not findings.
Reported f3-accepted raw tag object: 5092a5b (abbreviated). Do not compare a raw tag-object SHA to a peeled commit SHA or retag. Resolve refs/tags/f3-accepted^{commit} if needed.

## Conversation-reported receipts (raw log bytes not included)
24: logs\24_preimpl_checkpoint.log; 2845 bytes
Reported SHA-256: CB990B15ACDA8494A508FCFB7302018691627CFBB73966E5A6D005830B921492
25: logs\25_workspace_mismatch.log; 1021 bytes
Two inconsistent reported hash strings appear in the same owner message:
35BEC8FBAA7CC14BE94FC6D066B58D033F58BF4136A21E95D91F12EFC902F6
35BEC8FBAA7CC14BE94FC6D066B58D033F58BF4136A21E95D91F12EFFC902F6
Neither is certified here. Recompute from the original raw file when needed; do not choose one or repair a string by inference.
26: logs\26_workspace_identity.log; 2180 bytes
Reported SHA-256: 7560702B2297A397FFD15260DC2F3708958F6FCD58D1D4529E6645862DDCE172

## Remaining gate
Only Arena environment/content alignment remains open in this handoff. Preserve previous completed verification as reported; do not claim direct verification of missing raw files. No source edits or Git mutations until the alignment method and any required permission are resolved.
