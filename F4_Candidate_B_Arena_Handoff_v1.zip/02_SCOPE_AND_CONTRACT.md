# Candidate B scope — bounded handoff summary
## Objective
Align RECONCILED across enum/ORM/PostgreSQL CHECK; durable reconciliation-run persistence; ADMIN status/run endpoints; focused tests and prior regressions. Paper/Fake only. Do not expand into Candidate A, full order/Position lifecycle, adapter-ledger implementation or all F4 triggers without separate scope resolution.

## Original owner-approved proposed file list
app/core/enums.py
app/db/models/synthetic_stop.py
app/services/reconciliation.py
app/api/v1/system.py
alembic/versions/0007_f4_reconciled_alignment.py
tests/*reconciliation*
tests/*synthetic_stop*
tests/*system*

The initial authorization text described this as a proposed list and required stopping if another file became necessary. Treat it conservatively; do not expand wildcard interpretation silently. Later proposals for app/schemas/system.py, app/services/__init__.py, a new reconciliation_run model, broad tests/, alternative migration filenames, or model registry changes are NOT established owner-approved additions. Report exact necessary paths and rationale before editing them.

## Forbidden / preserved
Accepted migrations 0001–0006; real-exchange adapters; production configuration; secrets/signing keys; live/direct paths; unrelated order/Position lifecycle; dependencies; production Docker config; Git history/branch/remote mutations/reset/clean/rebase/force-push.
Additional conservative holds from subsequent planning: kill_switch.py; Fake/Paper adapters; tests/conftest.py; pyproject.toml; poetry.lock; alembic.ini; Docker/Compose/CI files; decision records and verification logs. No cleanup of unknown files.

## Design and acceptance
- Migration derives from actual existing revision identifier, not an assumed filename. Reported head: 0006_kill_switch_dual_approval. Preserve accepted migrations.
- Upgrade/downgrade tested only on explicitly identified disposable PostgreSQL. Incompatible RECONCILED data must cause explicit refusal or separately approved conversion; no silent deletion.
- Persist unique run identity, STARTED/SUCCEEDED/FAILED, timestamps, trusted actor identity and bounded failure information. Explain transaction boundaries and incomplete-run recovery.
- F4 sections 8/10/11 additionally govern run scope, discrepancies, blocking results, API idempotency and Audit/Outbox. Identify dependencies that cannot be delivered within this slice instead of faking success or broadening scope.
- GET /api/v1/system/reconciliation/status; POST /api/v1/system/reconciliation/run; ADMIN only. Missing/invalid auth 401; operational key 403; absent entity 404; conflict 409; unavailable dependency 503. Stable code/message/request_id; no secrets.
- POST requires Idempotency-Key, normalized scope and reason. Same key/payload returns original run; changed payload returns 409. Persist before processing; 202 for asynchronous processing with run_id/status/request_id. Status supports run_id filter.
- Do not claim meaningful full reconciliation without independently identifiable adapter state; comparing a record to itself is not sufficient.
- Keep LIVE_TRADING=false and PAPER_TRADING=true. No real exchange calls/credentials. No weakening tests, skipped regressions to manufacture PASS, false successful runs, or unapproved dependencies.
- Test status CHECK acceptance/rejection, durable run identity/success/failure, auth, identity trust, replay/conflict/concurrency, rollback/failure paths and downgrade policy. Map tests to actual pytest node IDs. Full F4 acceptance is separate from slice acceptance.

## Stop and request narrow resolution
Forbidden/new file needed; schema/contract ambiguity; destructive downgrade; unexpected repository drift; production/unknown database; external credentials; scope expansion. Preserve evidence and existing work.
